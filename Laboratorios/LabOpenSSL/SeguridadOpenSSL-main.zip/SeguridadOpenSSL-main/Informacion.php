<?PHP 
phpinfo();
?>