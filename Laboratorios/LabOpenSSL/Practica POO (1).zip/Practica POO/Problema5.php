<?php
class Animal {
    //Propiedades
    public $nombre;
    public $color;

    //Métodos
    function set_nombre($nombre){
        $this->nombre= $nombre;
    }
    function get_nombre(){
        return$this->nombre;
    }

}

$perro =new Animal();
$gato = new Animal();
$perro->set_nombre('Tom');
$gato->set_nombre('Jerry');
echo $dog ->get_nombre();
echo "<br>";
echo $gato->get_nombre();
?>