<?php
class Triangulo {

    //Creado por: Analía Solís
    //Grupo:1GS131
    //Fecha: 14/04/2025
    
    private $base;
    private $altura;

    public function __construct($base, $altura) {
        $this->base = $base;
        $this->altura = $altura;
    }

    public function calcularArea() {
        return ($this->base * $this->altura) / 2;
    }
}

// Validar que los datos llegaron por POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $base = $_POST['base'];
    $altura = $_POST['altura'];

    if (is_numeric($base) && is_numeric($altura)) {
        $triangulo = new Triangulo($base, $altura);
        $area = $triangulo->calcularArea();

        echo "<h2>Resultado:</h2>";
        echo "Base: $base cm<br>";
        echo "Altura: $altura cm<br>";
        echo "Área del triángulo: $area cm²";
    } else {
        echo "Por favor, ingresa valores numéricos válidos.";
    }
} else {
    echo "Acceso no permitido.";
}
?>