<?php

// PHP_EOL (end of line) introduce un salto de línea en PHP.

class Foo
{
    public function printItem($string)
    {
        echo 'Foo: ' . $string . PHP_EOL;
    }

    public function printPHP()
    {
        echo 'PHP is great.' . PHP_EOL;
    }
}

class Bar extends Foo
{
    public function printItem($string)
    {
        echo 'Bar: ' . $string . PHP_EOL;
    }
}

$foo = new Foo();
$bar = new Bar();

$foo->printItem('baz');  // Salida: 'Foo: baz'
echo "<br>";
$foo->printPHP();        // Salida: 'PHP is great'
echo "<br>";

$bar->printItem('baz');  // Salida: 'Bar: baz'
echo "<br>";
$bar->printPHP();        // Salida: 'PHP is great'
