<?php
class Coche {
    const RUEDAS = 4;
}

// Obtener el valor mediante el nombre de la clase:
echo Coche::RUEDAS;

// Obtener el valor mediante el objeto:
$miCoche = new Coche();
echo $miCoche::RUEDAS . "<BR>";
?>