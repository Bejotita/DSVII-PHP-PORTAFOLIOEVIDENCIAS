<?php
class Foo {
    public static function unMetodoEstatico() {
        // ...
        echo "Hola como estas <br>";
    }
}

// Forma #1
Foo::unMetodoEstatico();

// Forma #2
$nombre_clase = 'Foo';
$nombre_clase::unMetodoEstatico(); // A partir de PHP 5.3.0
?>