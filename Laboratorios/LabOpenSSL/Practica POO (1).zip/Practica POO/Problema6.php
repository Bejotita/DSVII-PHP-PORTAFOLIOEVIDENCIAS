<?php
class Mamifero extends Animal{
    function breathesAir(){
        echo "inhale";
    }
}

$caballo =new Mamifero;
$caballo->setName("Louis");
?>