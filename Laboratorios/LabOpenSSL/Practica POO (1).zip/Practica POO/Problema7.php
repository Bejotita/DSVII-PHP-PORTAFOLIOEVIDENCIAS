<?php
class Circulo {
    private $radio;
    private $perimetro;

    public function __construct($radio) {
        $this->radio = $radio;
        $this->perimetro = 2 * M_PI * $radio;
    }
}
?>