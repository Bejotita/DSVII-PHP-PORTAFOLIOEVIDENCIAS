document.addEventListener("DOMContentLoaded", () => {
    ListarProductos();

    document.getElementById('formulario').addEventListener('submit', async function (e) {
        e.preventDefault();

        const formData = new FormData(this);
        const id = formData.get('id');
        const accion = id ? 'Modificar' : 'Guardar';
        formData.append('accion', accion);

        try {
            const response = await fetch('registrar.php', {
                method: 'POST',
                body: formData
            });

             // Convierte la respuesta a JSON
            const data = await response.json();

            // Si fue exitoso, muestra SweetAlert y resetea el formulario
            if (data.success) {
                Swal.fire('¡Éxito!', data.message, 'success');
                this.reset();
                ListarProductos();
            } else {
                Swal.fire('Error', data.message, 'error');
            }

        } catch (error) {
            console.error(error);
            Swal.fire('Error', 'Error en la solicitud', 'error');
        }
    });
});

// Función para obtener y mostrar la lista de productos desde el servidor
async function ListarProductos() {
    const formData = new FormData();
    formData.append('accion', 'Buscar');

    const response = await fetch('registrar.php', {
        method: 'POST',
        body: formData
    });

    const data = await response.json();
    const tbody = document.querySelector("#tablaProductos tbody");
    tbody.innerHTML = "";

    // Si hay productos, los recorre y agrega filas a la tabla
    if (data.success && data.data.length > 0) {
        data.data.forEach(item => {
            const fila = document.createElement('tr');
            fila.innerHTML = `
                <td>${item.id}</td>
                <td>${item.codigo}</td>
                <td>${item.producto}</td>
                <td>${item.precio}</td>
                <td>${item.cantidad}</td>
                <td>
                    <button onclick='editarProducto(${JSON.stringify(item)})'>Editar</button>
                </td>
            `;
            tbody.appendChild(fila);
        });
    }
}

// Función que llena el formulario con los datos del producto seleccionado para editar
function editarProducto(producto) {
    document.getElementById('id').value = producto.id;
    document.getElementById('codigo').value = producto.codigo;
    document.getElementById('producto').value = producto.producto;
    document.getElementById('precio').value = producto.precio;
    document.getElementById('cantidad').value = producto.cantidad;

    Swal.fire('Editar producto', 'Modifica los campos y haz clic en Guardar', 'info');
}
