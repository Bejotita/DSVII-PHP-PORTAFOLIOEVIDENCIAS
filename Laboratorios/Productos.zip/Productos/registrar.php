<?php
header("Content-Type: application/json");
require_once "Modelo/Productos.php";

$accion = $_POST['accion'] ?? '';

//elementos del formulario
$producto = new Producto();
$producto->codigo = $_POST['codigo'] ?? '';
$producto->producto = $_POST['producto'] ?? '';
$producto->precio = $_POST['precio'] ?? 0;
$producto->cantidad = $_POST['cantidad'] ?? 0;

switch ($accion) {
    case 'Guardar':
    if ($producto->codigoExiste($producto->codigo)) {
        echo json_encode([
            'success' => false,
            'message' => 'El código ya está registrado. Debe ser único.'
        ]);
        break;
    }

    if ($producto->guardar()) {
        echo json_encode(['success' => true, 'message' => 'Producto guardado con éxito']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al guardar']);
    }
    break;


    case 'Modificar':
    $id = $_POST['id'] ?? 0;

    if ($producto->codigoExiste($producto->codigo, $id)) {
        echo json_encode([
            'success' => false,
            'message' => 'El código ya está registrado por otro producto.'
        ]);
        break;
    }

    if ($id && $producto->editar($id)) {
        echo json_encode(['success' => true, 'message' => 'Producto actualizado con éxito']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al actualizar']);
    }
    break;


    case 'Buscar':
        $resultados = $producto->buscar();
        echo json_encode(['success' => true, 'data' => $resultados]);
        break;

    default:
        echo json_encode(['success' => false, 'message' => 'Acción no válida']);
}
?>
