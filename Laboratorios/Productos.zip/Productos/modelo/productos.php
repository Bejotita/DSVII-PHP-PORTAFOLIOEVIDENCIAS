<?php
require_once 'conexion.php';

class Producto {
    private $db;
    public $codigo, $producto, $precio, $cantidad;

    //conexion a la bd
    public function __construct() {
        $this->db = (new DB())->conexion;
    }

    //función guardar
    public function guardar() {
        $sql = "INSERT INTO productos (codigo, producto, precio, cantidad) VALUES (?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$this->codigo, $this->producto, $this->precio, $this->cantidad]);
    }

    //función editar
    public function editar($id) {
        $sql = "UPDATE productos SET codigo=?, producto=?, precio=?, cantidad=? WHERE id=?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$this->codigo, $this->producto, $this->precio, $this->cantidad, $id]);
    }

    //función buscar
    public function buscar() {
        $sql = "SELECT * FROM productos";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    //si el código ya existe...
    public function codigoExiste($codigo, $id = null) {
    $sql = "SELECT id FROM productos WHERE codigo = ?";
    $params = [$codigo];

    // Si se está editando, se excluye el mismo ID
    if ($id !== null) {
        $sql .= " AND id != ?";
        $params[] = $id;
    }

    $stmt = $this->db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetch(PDO::FETCH_ASSOC) ? true : false;
}

}
?>
