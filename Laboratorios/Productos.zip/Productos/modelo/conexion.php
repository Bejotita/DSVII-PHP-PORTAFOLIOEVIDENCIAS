<?php
class DB {
    private $host = "localhost";
    private $dbname = "productosdb";
    private $user = "root";
    private $pass = "";
    public $conexion;

    //conexión a la bd
    public function __construct() {
        try {
            $this->conexion = new PDO("mysql:host=$this->host;dbname=$this->dbname", 
                $this->user, $this->pass);
            $this->conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die(json_encode(['success' => false, 'message' => 'Error en conexión: ' . $e->getMessage()]));
        }
    }
}
?>
