<?php
require 'conexion.php';
require 'ProductosController.php';

$metodo = $_SERVER['REQUEST_METHOD'];

switch ($metodo) {
    case 'POST':
        crearProducto($conn);
        break;

    case 'GET':
        obtenerProductos($conn);
        break;

    case 'PUT':
    parse_str($_SERVER['QUERY_STRING'], $query);
    $id = $query['id'] ?? null;

    if ($id) {
        actualizarProducto($conn, $id);
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Falta el parámetro ID"]);
    }
    break;


    default:
        http_response_code(405);
        echo json_encode(["error" => "Método no permitido"]);
        break;
}
?>
