<?php

//Post creación de productos
function crearProducto($conn) {
    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data["codigo"], $data["producto"], $data["precio"], $data["cantidad"])) {
        http_response_code(400);
        echo json_encode(["error" => "Faltan datos"]);
        return;
    }

    $sql = "INSERT INTO productos (codigo, producto, precio, cantidad) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$data["codigo"], $data["producto"], $data["precio"], $data["cantidad"]]);

    http_response_code(201);
    echo json_encode(["mensaje" => "Producto creado"]);
}

//GET Listado de Productos
function obtenerProductos($conn) {
    $stmt = $conn->query("SELECT * FROM productos");
    $productos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    http_response_code(200);
    echo json_encode($productos);
}


//PUT Actualización de Productos por id
function actualizarProducto($conn, $id) {
    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data["codigo"], $data["producto"], $data["precio"], $data["cantidad"])) {
        http_response_code(400);
        echo json_encode(["error" => "Faltan datos para actualizar"]);
        return;
    }

    // Verifica si el producto existe antes de actualizar
    $stmt = $conn->prepare("SELECT * FROM productos WHERE id = ?");
    $stmt->execute([$id]);

    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        echo json_encode(["error" => "Producto no encontrado"]);
        return;
    }

    // Actualiza los datos
    $sql = "UPDATE productos SET codigo = ?, producto = ?, precio = ?, cantidad = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        $data["codigo"],
        $data["producto"],
        $data["precio"],
        $data["cantidad"],
        $id
    ]);

    http_response_code(200);
    echo json_encode(["mensaje" => "Producto actualizado correctamente"]);
}


?>