<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Traer las edades del formulario
    $edades = [
        $_POST['edad1'],
        $_POST['edad2'],
        $_POST['edad3'],
        $_POST['edad4'],
        $_POST['edad5']
    ];

    //Definicion de variables
    $ninos=0;
    $adolecentes=0;
    $adultos=0;
    $adultosMayores=0;

    for ($cont = 0; $cont < count($edades); $cont++) {
        if ($edades[$cont] >= 0 and $edades[$cont]<=12) {
            $ninos++;
        }elseif ($edades[$cont] >= 13 and $edades[$cont]<=17) {
            $adolecentes++;
        }elseif ($edades[$cont] >= 18 and $edades[$cont]<=64){
            $adultos++;
        }else {
            $adultosMayores++;
        }
    }

    echo "Categorías:<br> niños (0-12) <br>adolescentes (13-17) <br>adultos(18-64) <br>adultos mayores (65+).";

    echo "Edades introducidas: <br>";

    for ($cont = 0; $cont < count($edades); $cont++) {
        echo "<br>".$edades[$cont];
    }

    echo "<br>Hay $ninos niño/s,<br> $adolecentes adolecente/s,<br> $adultos adulto/s<br>y $adultosMayores adulto/s mayor/es. <br>";
    echo "<a href=../Problema5/Problema5html.php>Problema#5</a>";

}
?>

