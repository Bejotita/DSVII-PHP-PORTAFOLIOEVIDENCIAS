<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estiloIndex.css">
    <title>Area de un Circulo</title>
</head>
<body>
    <div class="container">
        <div class="Header">
            <h1 class="Centrar">
                Suma de números positivos
            </h1>
        </div>

        <?php include '../navbar.php'; ?>

        <div class="body">
            <h2 class="Justificar">
                Introduce 5 edades de personas, el programa los clasificara en niños, adolecentes, adultos y adultos mayores.
            </h2>

            <form method="post" action="Problema5.php">
                <br>
                    <p class="Justificar">Edad 1: </p>
                    <input type="number" name="edad1" id="edad1" required min="0">
                    <br>
                    <p class="Justificar">Edad 2: </p>
                    <input type="number" name="edad2" id="edad2" required min="0">
                    <br>
                    <p class="Justificar">Edad 3: </p>
                    <input type="number" name="edad3" id="edad3" required min="0">
                    <br>
                    <p class="Justificar">Edad 4: </p>
                    <input type="number" name="edad4" id="edad4" required min="0">
                    <br>
                    <p class="Justificar">Edad 5: </p>
                    <input type="number" name="edad5" id="edad5" required min="0">
                <br><br>
                <button type="submit">Clasificar</button>
            </form>
        </div>
    </div>

    <?php include '../footer.php'; ?>
    
</body>
</html>