<?php

$sumImpares=0;
$sumPares=0;

for($count=0;$count<=200;$count++){
    if(($count%2)==0){
        $sumPares+=$count;
    }
    else{
        $sumImpares+=$count;
    }
}

echo "La suma de los números pares es de $sumPares.<br> La suma de los números impares es de $sumImpares.<br>";
echo "<a href=../Problema4/Problema4html.php>Problema#4</a>";


?>