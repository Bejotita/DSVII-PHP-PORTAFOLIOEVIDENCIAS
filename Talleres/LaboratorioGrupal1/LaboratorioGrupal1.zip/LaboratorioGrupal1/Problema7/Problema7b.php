<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $notas = $_POST['notas'];
    $cantidad = $_POST['cantidad'];

    $notas_float = array_map('floatval', $notas);

    // Calcular el promedio
    $suma = 0;
    foreach ($notas_float as $nota) {
        $suma += $nota;
    }
    $promedio = $suma / count($notas_float);

    // Calcular la desviación estándar
    $sumatoria = 0;
    foreach ($notas_float as $nota) {
        $sumatoria += pow($nota - $promedio, 2);
    }
    $desviacion = sqrt($sumatoria / count($notas_float));

    // Nota mínima y máxima
    $min = min($notas_float);
    $max = max($notas_float);

    echo "<h3>Resultados:</h3>";
    echo "<p>Promedio: " . round($promedio, 2) . "</p>";
    echo "<p>Desviación estándar: " . round($desviacion, 2) . "</p>";
    echo "<p>Nota mínima: $min</p>";
    echo "<p>Nota máxima: $max</p>";

    echo "<a href=../Problema7/Problema7html.php>Problema#7</a>";

}
?>
