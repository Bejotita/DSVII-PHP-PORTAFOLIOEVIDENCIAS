<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estiloIndex.css">
    <title>Problema #7 - Ingresar cantidad de notas</title>
</head>
<body>

    <div class="container">
        <div class="Header">
            <h1 class="Centrar">Problema #7 - Ingresar cantidad de notas</h1>
        </div>

        <?php include '../navbar.php'; ?>

        <form action="Problema7.php" method="get">
            <label for="cantidad">¿Cuántas notas deseas ingresar?</label>
            <input type="number" name="cantidad" id="cantidad" min="1" required>
            <br><br>
            <button type="submit">Continuar</button>
        </form>        
    </div>

    <?php include '../footer.php'; ?>

</body>
</html>
