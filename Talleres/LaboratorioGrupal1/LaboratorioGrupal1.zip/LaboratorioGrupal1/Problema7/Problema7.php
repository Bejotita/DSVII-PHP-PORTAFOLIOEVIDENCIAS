<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estiloIndex.css">
    <title>Problema #7 - Ingresar Notas</title>
</head>
<body>

    <div class="container">
        <div class="Header">
            <h1 class="Centrar">Problema #7 - Ingresar Notas</h1>
        </div>

        <?php include '../navbar.php'; ?>

        <h3>Ingresa las notas:</h3>
        <form action="Problema7b.php" method="post">
            <?php
                $cantidad = isset($_GET['cantidad']) ? $_GET['cantidad'] : 0;
                for ($i = 0; $i < $cantidad; $i++) {
                    echo "Nota " . ($i + 1) . ": <input type='number' name='notas[]' step='0.01' min='0' max='100' required><br>";
                }
            ?>
            <input type="hidden" name="cantidad" value="<?= $cantidad ?>">
            <br><button type="submit">Calcular</button>
        </form>

    </div>

    <?php include '../footer.php'; ?>

</body>
</html>


