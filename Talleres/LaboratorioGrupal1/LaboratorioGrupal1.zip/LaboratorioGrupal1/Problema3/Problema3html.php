<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estiloIndex.css">
    <title>Suma de los primeros 10 números pares</title>
</head>
<body>
    <div class="container">
        <div class="Header">
            <h1 class="Centrar">
                Suma de los primeros 10 números pares
            </h1>
        </div>

        <?php include '../navbar.php'; ?>

        <div class="body">
            <h2 class="Justificar">
                El siguiente botón dará el resultado de la suma de los primeros 10 números pares.
            </h2>

            <form method="post" action="../Problema3/Problema3.php">
                <br>
                    <input type="submit" value="Confirmar">   
            </form>
        </div>

    </div>

    <?php include '../footer.php'; ?>

</body>
</html>