<?php
$sumPares=0;

for($count=0;$count<=20;$count=$count+2){
        $sumPares+=$count;
}

echo "La suma de los primeros 10 números pares es de $sumPares.<br>";
echo "<a href=../Problema3/Problema3html.php>Problema#3</a>";
?>