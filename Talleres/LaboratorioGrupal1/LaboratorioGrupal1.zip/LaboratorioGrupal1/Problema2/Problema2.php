<?php
$suma=0;

for($count=0;$count<=1000;$count++){
    $suma+=$count;
}
echo "La suma de los numeros del 1 al 1000 es: $suma <br>";
/*$count es un contador que con el metodo for ira incrementando el valor y $sum es el acumulador 
encargado de recibir el incremento de $count*/

echo "<a href=../Problema2/Problema2html.php>Problema#2</a>";

?>