<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $n = intval($_POST["cantidad"]);

    echo "<h2>Los $n primeros múltiplos de 4:</h2>";
    echo "<ul>";

    for ($i = 1; $i <= $n; $i++) {
        $resultado = 4 * $i;
        echo "<li>4 × $i = $resultado</li>";
    }

    echo "</ul>";
    echo "<a href='../Problema10/Problema10html.php'>Problema#10</a>";
}
?>
