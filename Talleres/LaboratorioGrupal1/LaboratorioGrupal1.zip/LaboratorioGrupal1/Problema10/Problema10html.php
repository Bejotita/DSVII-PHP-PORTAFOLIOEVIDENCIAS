<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estiloIndex.css">
    <title>Problema #10 - Múltiplos de 4</title>
</head>
<body>

    <div class="container">
        <div class="Header">
            <h1 class="Centrar">Problema #10 - Múltiplos de 4</h1>
        </div>

        <?php include '../navbar.php'; ?>

        <form action="Problema10.php" method="post">
            <label for="cantidad">¿Cuántos múltiplos de 4 deseas mostrar?</label>
            <input type="number" name="cantidad" id="cantidad" min="1" required>
            <br><br>
            <button type="submit">Calcular</button>
        </form>
    </div>

    <?php include '../footer.php'; ?>

</body>
</html>
