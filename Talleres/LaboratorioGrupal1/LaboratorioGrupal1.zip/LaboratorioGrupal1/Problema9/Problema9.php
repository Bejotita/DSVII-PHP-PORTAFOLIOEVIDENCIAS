<?php
echo "<h2>Las 15 primeras potencias de 4:</h2>";
echo "<ul>";

for ($i = 1; $i <= 15; $i++) {
    $potencia = pow(4, $i);
    echo "<li>4<sup>$i</sup> = $potencia</li>";
}

echo "</ul>";
echo "<a href='../Problema9/Problema9html.php'>Problema#9</a>";
?>
