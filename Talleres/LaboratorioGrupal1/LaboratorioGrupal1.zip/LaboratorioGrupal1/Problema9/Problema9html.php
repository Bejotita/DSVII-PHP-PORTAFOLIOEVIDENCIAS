<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estiloIndex.css">
    <title>Potencias de 4</title>
</head>
<body>

    <div class="container">
        <div class="Header">
            <h1 class="Centrar">Potencias de 4</h1>
        </div>

        <?php include '../navbar.php'; ?>

        <form action="Problema9.php" method="post">
            <p>Haz clic en el botón para ver las 15 primeras potencias de 4:</p>
            <button type="submit">Mostrar</button>
        </form>
    </div>

    <?php include '../footer.php'; ?>
</body>
</html>
