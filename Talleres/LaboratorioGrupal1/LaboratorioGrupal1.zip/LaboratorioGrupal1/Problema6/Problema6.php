<?php
 $presupuesto = $_POST['presupuesto'];

 $presupuestoGinecologia=number_format($presupuesto*0.40,2,'.',' ');
 $presupuestoPediatria=number_format($presupuesto*0.25,2,'.',' ');
 $presupuestoTraumatologia=number_format($presupuesto*0.35,2,'.',' ');

echo "El presupuesto anual es de:  $presupuesto. <br>El presupuesto para el área de Ginecología es de: $presupuestoGinecologia, <br>El presupuesto para el área de Pediatría es de: $presupuestoPediatria, <br>El presupuesto para el área de Traumatología es de: $presupuestoTraumatologia.<br>";
echo "<a href=../Problema6/Problema6html.php>Problema#6</a>";

?>