<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estiloIndex.css">
    <title>Presupuesto por Área</title>
</head>
<body>

    <div class="container">
        <div class="Header">
            <h1 class="Centrar">
                Presupuesto por Área
            </h1>
        </div>
        
        <?php include '../navbar.php'; ?>
    
        <form action="Problema6.php" method="post">
            Ingrese su Presupuesto:
            <input type="number" name="presupuesto" id="presupuesto" required min="0" step="0.01">
            <br>
            <input type="submit" value="Confirmar">
        </form>

    </div>
    
    <?php include '../footer.php'; ?>

</body>
</html>