<footer>
        <br>
        <p>
            <img src="../img/copyright.png" width="20">
            copyright 2025 | autores: <a class="blanco" href="../index.php">Analía Solís y Joseph Guerrero</a>
            <span><?php
                echo "<br>Ejecución: ";
                echo date("d/m/y");
            ?></span>
        </p>
</footer>