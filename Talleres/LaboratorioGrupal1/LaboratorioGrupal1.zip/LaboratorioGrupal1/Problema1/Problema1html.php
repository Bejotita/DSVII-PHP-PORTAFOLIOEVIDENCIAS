<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estiloIndex.css">
    <title>Suma de números positivos</title>
</head>
<body>
    <div class="container">
        <div class="Header">
            <h1 class="Centrar">
                Suma de números positivos
            </h1>
        </div>

        <?php include '../navbar.php'; ?>

        <div class="body">
            <h2 class="Justificar">
                Introduce 5 números, el programa sumará los positivos.
            </h2>

            <form method="post" action="Problema1.php">
                <br>
                    <p class="Justificar">Número 1: </p>
                    <input type="number" name="numero1" id="numero1" required>
                    <br>
                    <p class="Justificar">Número 2: </p>
                    <input type="number" name="numero2" id="numero2" required>
                    <br>
                    <p class="Justificar">Número 3: </p>
                    <input type="number" name="numero3" id="numero3" required>
                    <br>
                    <p class="Justificar">Número 4: </p>
                    <input type="number" name="numero4" id="numero4" required>
                    <br>
                    <p class="Justificar">Número 5: </p>
                    <input type="number" name="numero5" id="numero5" required>
                <br><br>
                <button type="submit">Calcular</button>
            </form>
        </div>
    </div>

    <?php include '../footer.php'; ?>
    
</body>
</html>