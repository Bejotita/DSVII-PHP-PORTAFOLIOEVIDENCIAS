<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Traer el valor del formulario
    $numero = [
        $_POST['numero1'],
        $_POST['numero2'],
        $_POST['numero3'],
        $_POST['numero4'],
        $_POST['numero5']
    ];

    // Inicializar variables
    $suma = 0;
    $numerosPositivos = [];

    for ($cont = 0; $cont < count($numero); $cont++) {
        if ($numero[$cont] >= 0) {
            $numerosPositivos[] = $numero[$cont];
            $suma += $numero[$cont];
        }
    }

    echo "La suma de los números positivos: ";

    for ($cont = 0; $cont < count($numerosPositivos); $cont++) {
        echo "<br>".$numerosPositivos[$cont];
    }

    echo "<br>Es de: $suma <br>";
    echo "<a href=../Problema1/Problema1html.php>Problema#1</a>";

}
?>

