<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estiloIndex.css">
    <title>Laboratorio#1</title>
</head>
<body>
    <div class="container">
        <div class="Header">
            <h1 class="Centrar">
                Bienvenida Profesora a mi Laboratorio#1
            </h1>
        </div>

        <nav>
            <a href="Problema1/Problema1html.php">Problema#1</a>
            <a href="Problema2/Problema2html.php">Problema#2</a>
            <a href="Problema3/Problema3html.php">Problema#3</a>
            <a href="Problema4/Problema4html.php">Problema#4</a>
            <a href="Problema5/Problema5html.php">Problema#5</a>
            <a href="Problema6/Problema6html.php">Problema#6</a>
            <a href="/Problema7/Problema7html.php">Problema#7</a>
            <a href="Problema8/Problema8html.php">Problema#8</a>
            <a href="Problema9/Problema9html.php">Problema#9</a>
            <a href="Problema10/Problema10html.php">Problema#10</a>
        </nav>

        <div class="body">
            <Strong>
                Nombre: Analía Solís <br>
                Cédula: 8-1015-955 <br>
                <br>
                Nombre: Joseph Guerrero <br>
                Cédula: 2-754-1867 <br>
                
                Grupo: 1GS131
            </Strong>   
        </div>
    </div>

    <footer>
        <br>
        <p>
            <img src="img/copyright.png" width="20">
            copyright 2025 | autores: <a class="blanco" href="../index.php">Analía Solís y Joseph Guerrero</a>
            <span><?php
                echo "<br>Ejecución: ";
                echo date("d/m/y");
            ?></span>
        </p>
    </footer>
    
</body>
</html>