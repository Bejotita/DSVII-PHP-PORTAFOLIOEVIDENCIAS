<?php
function obtenerEstacion($dia, $mes) {
    // Convertimos a formato comparable MMDD
    $fecha = intval(sprintf('%02d%02d', $mes, $dia)); // MMDD

    if ($fecha >= 1221 || $fecha <= 320) {
        return "Verano";
    } elseif ($fecha >= 321 && $fecha <= 621) {
        return "Otoño";
    } elseif ($fecha >= 622 && $fecha <= 922) {
        return "Invierno";
    } elseif ($fecha >= 923 && $fecha <= 1220) {
        return "Primavera";
    } else {
        return "Fecha inválida";
    }
    
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dia = intval($_POST['dia']);
    $mes = intval($_POST['mes']);
    $estacion = obtenerEstacion($dia, $mes);

    $fechaFormateada = sprintf('%02d-%02d', $dia, $mes);

    echo "<h2>Resultado:</h2>";
    echo "<p>La estación del año para el $fechaFormateada es: <strong>$estacion</strong></p>";
    echo "<a href='../Problema8/Problema8html.php'>Problema#8</a>";
}
?>
