<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/estiloIndex.css">
    <title>Estación del Año</title>
</head>
<body>

    <div class="container">
        <div class="Header">
            <h1 class="Centrar">Estación del Año</h1>
        </div>

        <?php include '../navbar.php'; ?>

        <form action="Problema8.php" method="post">
            <label for="dia">Día:</label>
            <input type="number" name="dia" min="1" max="31" required><br>

            <label for="mes">Mes:</label>
            <input type="number" name="mes" min="1" max="12" required><br><br>

            <button type="submit">Obtener estación</button>
        </form>
    </div>

    <?php include '../footer.php'; ?>

</body>
</html>
