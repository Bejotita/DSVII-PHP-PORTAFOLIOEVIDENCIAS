<?php
        class Persona {
            private $nombre;
            private $apellido;
            private $feNac;
            private $numId;

            public function __construct($nombre, $apellido, $feNac, $numId) {
                $this->nombre = $nombre;
                $this->apellido = $apellido;
                $this->feNac = $feNac;
                $this->numId = $numId;
            }

            public function MostrarNombre() {return $this->nombre;}
            public function MostrarApellido() {return $this->apellido;}
            public function MostrarFechaNacimiento() {return $this->feNac;}
            public function MostrarNumeroDeIdentificacion() {return $this->numId;}
        }

        class Estudiante extends Persona {
            private $idColab;

            public function __construct($nombre, $apellido, $feNac, $numId, $idColab) {
                parent::__construct($nombre, $apellido, $feNac, $numId);
                $this->idColab = $idColab;
            }

            public function MostrarIdColaborador() {return $this->idColab;}
        }

        class Profesor extends Persona {
            private $salario;

            public function __construct($nombre, $apellido, $feNac, $numId, $salario) {
                parent::__construct($nombre, $apellido, $feNac, $numId);
                $this->salario = $salario;
            }

            public function MostrarSalario() {return $this->salario;}
        }
?>