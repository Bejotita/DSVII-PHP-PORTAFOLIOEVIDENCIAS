<?php
class Temperatura {
    private float $valor;
    private string $unidad;

    public function __construct(float $valor, string $unidad) {
        $this->valor = $valor;
        $this->unidad = strtolower($unidad);
    }

    public function convertir(): float {
        if ($this->unidad === 'c') {
            return ($this->valor * 9/5) + 32; // Celsius a Fahrenheit
        } elseif ($this->unidad === 'f') {
            return ($this->valor - 32) * 5/9; // Fahrenheit a Celsius
        } else {
            throw new Exception("Unidad no válida. Use 'C' o 'F'.");
        }
    }

    public function diagnostico(): string {
        $celsius = $this->unidad === 'c' ? $this->valor : $this->convertir();
        if ($celsius < 35) {
            return "Hipotermia";
        } elseif ($celsius >= 35 && $celsius < 37) {
            return "Temperatura corporal baja";
        } elseif ($celsius >= 37 && $celsius < 38) {
            return "Normal";
        } elseif ($celsius >= 38 && $celsius < 40) {
            return "Fiebre";
        } elseif ($celsius >= 40) {
            return "Hipertermia";
        }
    }

    public function mostrarResultado(): void {
        $convertido = $this->convertir();
        $unidadDestino = $this->unidad === 'c' ? 'Fahrenheit' : 'Celsius';
        $unidadOriginal = strtoupper($this->unidad);
        $unidadConvertida = $this->unidad === 'c' ? 'F' : 'C';

        echo "<div class='resultado'>";
        echo "<h2>Resultado:</h2>";
        echo "<p>Temperatura original: {$this->valor}°{$unidadOriginal}</p>";
        echo "<p>Convertida a $unidadDestino: " . round($convertido, 2) . "°$unidadConvertida</p>";
        echo "<p><strong>Diagnóstico:</strong> " . $this->diagnostico() . "</p>";
        echo "</div>";
    }
}

// Lógica principal
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $valor = floatval($_POST["valor"]);
    $unidad = $_POST["unidad"];

    $temp = new Temperatura($valor, $unidad);
    $temp->mostrarResultado();
}
?>
