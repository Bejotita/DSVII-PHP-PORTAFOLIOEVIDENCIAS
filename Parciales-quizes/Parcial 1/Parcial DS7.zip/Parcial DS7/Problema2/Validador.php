<?php
class Validador {
    public static function validarLado($valor) {
        return is_numeric($valor) && $valor > 0;
    }
}
?>
