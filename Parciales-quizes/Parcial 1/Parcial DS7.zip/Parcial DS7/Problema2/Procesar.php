<?php
include_once 'Rectangulo.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $base = $_POST['base'];
    $altura = $_POST['altura'];

    try {
        $rect = new Rectangulo($base, $altura);

        echo "<h2>Resultados:</h2>";
        echo "Área: " . $rect->calcularArea() . "<br>";
        echo "Perímetro: " . $rect->calcularPerimetro() . "<br>";
        echo "Diagonal: " . round($rect->calcularDiagonal(), 2) . "<br>";
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
