<?php
include_once 'Validador.php';

class Rectangulo {
    private $base;
    private $altura;

    public function __construct($base, $altura) {
        if (!Validador::validarLado($base) || !Validador::validarLado($altura)) {
            throw new Exception("Base y altura deben ser números positivos.");
        }

        $this->base = $base;
        $this->altura = $altura;
    }

    public function getBase() {
        return $this->base;
    }

    public function getAltura() {
        return $this->altura;
    }

    public function calcularArea() {
        return $this->base * $this->altura;
    }

    public function calcularPerimetro() {
        return 2 * ($this->base + $this->altura);
    }

    public function calcularDiagonal() {
        return sqrt(pow($this->base, 2) + pow($this->altura, 2));
    }
}
?>
